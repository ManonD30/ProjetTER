How to run YAM++ v.2102

1. For Window machine:  

> runGUI.bat

2. For Linux machine

$ chmod +x runGUI.sh
$ ./runGUI.sh

How to use YAM++ v. 2012 

1. Import the whole project in Eclipse

2. For running YAM++ without GUI: src/main/MainProgram.java

3. For running YAM++ with GUI: src/yamgui/test/main.java

An example of using GUI can be seen at:

http://www.lirmm.fr/yam-plus-plus/YAMGUI_demo.avi

NOTE:

The input ontologies are always named: source.rdf (source.owl) and target.rdf (.owl). They are stored in the same folder.
By default, YAM++ will take default input ontologies. If one wants to run with other ontologies, it is required to provide the path to input ontologies as argument.


