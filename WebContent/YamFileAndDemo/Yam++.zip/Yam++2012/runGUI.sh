#!/bin/sh

java -jar Main.jar yamgui.test.main
